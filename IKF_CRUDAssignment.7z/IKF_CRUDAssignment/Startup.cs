﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(IKF_CRUDAssignment.Startup))]
namespace IKF_CRUDAssignment
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
